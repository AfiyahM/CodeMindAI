import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Github, Play, Settings, Save } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export type Project = {
  id?: string;
  name: string;
};

type ProjectContextValue = {
  currentProject: Project | null;
  saveProject: () => Promise<void> | void;
  runCode: () => Promise<void> | void;
  setCurrentProject: (p: Project | null) => void;
};

const ProjectContext = createContext<ProjectContextValue>({
  currentProject: null,
  saveProject: async () => {},
  runCode: async () => {},
  setCurrentProject: () => {},
});

export const ProjectProvider: React.FC<{ children?: ReactNode }> = ({ children }) => {
  const [currentProject, setCurrentProject] = useState<Project | null>(null);

  const saveProject = async () => {
    // TODO: replace with real save logic
    console.log('saveProject called');
  };

  const runCode = async () => {
    // TODO: replace with real run logic
    console.log('runCode called');
  };

  return (
    <ProjectContext.Provider value={{ currentProject, saveProject, runCode, setCurrentProject }}>
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = () => useContext(ProjectContext);

export const Toolbar: React.FC = () => {
  const { user, signInWithGitHub, signOut } = useAuth();
  const { currentProject, saveProject, runCode } = useProject();

  return (
    <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
      <div className="flex items-center space-x-4">
        <div className="text-lg font-bold text-blue-400">CodeMind.AI</div>
        {currentProject && (
          <div className="flex items-center space-x-2 text-sm text-gray-300">
            <span>/</span>
            <span>{currentProject.name}</span>
          </div>
        )}
      </div>

      <div className="flex items-center space-x-2">
        {currentProject && (
          <>
            <button
              onClick={runCode}
              className="flex items-center space-x-1 px-3 py-1 bg-green-600 hover:bg-green-500 rounded text-sm transition-colors"
            >
              <Play size={14} />
              <span>Run</span>
            </button>

            <button
              onClick={saveProject}
              className="flex items-center space-x-1 px-3 py-1 bg-blue-600 hover:bg-blue-500 rounded text-sm transition-colors"
            >
              <Save size={14} />
              <span>Save</span>
            </button>
          </>
        )}

        <button className="p-2 hover:bg-gray-700 rounded transition-colors">
          <Settings size={16} />
        </button>

        {user ? (
          <div className="flex items-center space-x-2">
            <img
              src={user.photoURL || ''}
              alt="Profile"
              className="w-6 h-6 rounded-full"
            />
            <span className="text-sm">{user.displayName}</span>
            <button
              onClick={signOut}
              className="text-xs text-gray-400 hover:text-white"
            >
              Sign Out
            </button>
          </div>
        ) : (
          <button
            onClick={signInWithGitHub}
            className="flex items-center space-x-1 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm transition-colors"
          >
            <Github size={14} />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default Toolbar;
